package com.ejemplo.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendJavaApplicationTests {

	@Test
	void contextLoads() {
	}

}
